# Device Executor - README

Device Executor adalah aplikasi yang berjalan di device lokal untuk mengeksekusi automation tests menggunakan Chrome/Chromium. Ini mengatasi limitasi Vercel yang tidak support Chromium.

## Arsitektur

```
┌─────────────────┐
│    Frontend     │  (React)
│  (Vercel)       │
└────────┬────────┘
         │
         │ HTTP/WS
         ▼
┌─────────────────┐
│   Backend API   │  (Vercel/Hono)
│ (Vercel)        │
└────────┬────────┘
         │
         │ WebSocket/REST
         ▼
┌─────────────────────┐
│  Device Executor    │  (Node.js + Playwright)
│  (User's Device)    │
│  - Chrome/Chromium  │
│  - Playwright       │
└─────────────────────┘
```

## Installation

```bash
npm install
```

## Configuration

1. Copy `.env.example` ke `.env`:
```bash
cp .env.example .env
```

2. Edit `.env` dan set konfigurasi:
```env
DEVICE_NAME=my-test-device
DEVICE_TOKEN=your-secure-token
BACKEND_URL=http://localhost:5000
```

## Running

### Development
```bash
npm run dev
```

### Production
```bash
npm start
```

## API Endpoints

### REST API
- `GET /health` - Health check
- `GET /status` - Device status
- `POST /execute` - Execute automation (fallback method)

### WebSocket Messages

#### Client → Server
```json
{
  "type": "execute_automation",
  "executionId": "uuid",
  "data": {
    "steps": [...],
    "stopOnFailure": true
  }
}
```

#### Server → Client
```json
{
  "type": "execution_progress",
  "executionId": "uuid",
  "progress": {
    "currentStep": 1,
    "totalSteps": 5,
    "status": "passed"
  }
}
```

## How It Works

1. **Registration**: Device Executor register ke Backend dengan unique device ID
2. **Listening**: Menunggu perintah execute dari Frontend/Backend via WebSocket
3. **Execution**: Menggunakan Playwright untuk execute automation steps
4. **Reporting**: Mengirim hasil eksekusi kembali ke Backend
5. **Display**: Frontend menampilkan hasil dari Backend

## Environment Variables

- `DEVICE_NAME` - Nama device (default: random)
- `DEVICE_TOKEN` - Token untuk authentication (default: random UUID)
- `BACKEND_URL` - URL backend API (default: http://localhost:5000)
- `CHROME_PATH` - Path ke Chrome/Chromium executable (optional)
- `LOG_LEVEL` - Logging level (debug/info/warn/error)
- `PORT` - Port yang di-listen (default: 3000)

## Integration dengan Backend

Backend perlu di-update dengan API endpoints baru:
- `POST /api/device-executor/register` - Register device
- `POST /api/device-executor/execute` - Send execution request
- `POST /api/device-executor/execution-result` - Receive execution result
- `POST /api/device-executor/execution-error` - Receive execution error

## Integration dengan Frontend

Frontend perlu di-update untuk:
1. Detect device executors yang tersedia
2. Mengirim perintah execute ke device pilihan
3. Menampilkan real-time progress dari execution

## Security Considerations

- Gunakan secure HTTPS untuk production
- Validate device token di backend
- Rate limit execution requests
- Log semua execution attempts
