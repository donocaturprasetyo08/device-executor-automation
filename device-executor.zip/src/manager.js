/**
 * DeviceExecutorManager - Manage device registration dan communication dengan backend
 */

import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';

export class DeviceExecutorManager {
  constructor(options = {}) {
    this.deviceName = options.deviceName || `device-${uuidv4().slice(0, 8)}`;
    this.deviceToken = options.deviceToken || uuidv4();
    this.backendUrl = options.backendUrl || 'http://localhost:5000';
    this.deviceId = uuidv4();
    this.isConnected = false;
    this.lastHeartbeat = Date.now();
  }

  async registerDevice() {
    try {
      const response = await axios.post(
        `${this.backendUrl}/api/device-executor/register`,
        {
          device_name: this.deviceName,
          device_token: this.deviceToken,
          device_id: this.deviceId,
          capabilities: {
            browser: 'chromium',
            playwright: true,
            video_recording: false
          }
        },
        { timeout: 5000 }
      );

      if (response.data.success) {
        this.isConnected = true;
        console.log(`[Manager] Device registered successfully`);
        return true;
      }
      return false;
    } catch (error) {
      console.error(`[Manager] Registration failed:`, error.message);
      throw error;
    }
  }

  async reportExecutionResult(executionId, result) {
    try {
      await axios.post(
        `${this.backendUrl}/api/device-executor/execution-result`,
        {
          executionId,
          device_id: this.deviceId,
          result
        },
        {
          headers: {
            Authorization: `Bearer ${this.deviceToken}`
          }
        }
      );
    } catch (error) {
      console.error(`[Manager] Failed to report result:`, error.message);
    }
  }

  async reportExecutionError(executionId, error) {
    try {
      await axios.post(
        `${this.backendUrl}/api/device-executor/execution-error`,
        {
          executionId,
          device_id: this.deviceId,
          error: error.message,
          stack: error.stack
        },
        {
          headers: {
            Authorization: `Bearer ${this.deviceToken}`
          }
        }
      );
    } catch (err) {
      console.error(`[Manager] Failed to report error:`, err.message);
    }
  }

  getDeviceId() {
    return this.deviceId;
  }

  isConnected() {
    return this.isConnected;
  }

  updateHeartbeat() {
    this.lastHeartbeat = Date.now();
  }
}
