/**
 * PlaywrightExecutor - Execute automation steps menggunakan Playwright
 */

import { chromium } from 'playwright';

export class PlaywrightExecutor {
  constructor(options = {}) {
    this.headless = options.headless === true; // Headless false by default (visible mode)
    this.timeoutMs = options.timeout || 30000;
    this.browser = null;
    this.page = null;
    this.context = null;
    this.pages = []; // Array to store all open pages/tabs
    this.currentPageIndex = 0; // Track current active page index
    this.contexts = []; // Array to store all open contexts
    this.currentContextIndex = 0; // Track current active context index
    this.isExecuting = false;
    this.totalExecutions = 0;
    this.chromiumPath = process.env.CHROME_PATH || null;
    this.variables = {}; // Store captured variables during execution
    
    // Execution queue untuk handle batch execution secara sequential
    this.executionQueue = [];
    this.isProcessingQueue = false;
  }

  async launchBrowser() {
    try {
      const launchOptions = {
        headless: this.headless
      };

      // Jika custom chromium path disediakan
      if (this.chromiumPath) {
        launchOptions.executablePath = this.chromiumPath;
      }

      this.browser = await chromium.launch(launchOptions);
      this.context = await this.browser.newContext();
      this.page = await this.context.newPage();
      this.page.setDefaultTimeout(this.timeoutMs);
      this.pages = [this.page]; // Initialize pages array with first page
      this.currentPageIndex = 0;
      this.contexts = [this.context]; // Initialize contexts array with first context
      this.currentContextIndex = 0;

      console.log(`[Executor] Browser launched successfully`);
      return true;
    } catch (error) {
      console.error(`[Executor] Failed to launch browser:`, error);
      throw error;
    }
  }

  async closeBrowser() {
    try {
      if (this.page) {
        await this.page.close();
      }
      if (this.context) {
        await this.context.close();
      }
      if (this.browser) {
        await this.browser.close();
      }
    } catch (error) {
      console.error(`[Executor] Error closing browser:`, error);
    }
  }

  /**
   * Replace variable placeholders in text with captured variable values
   * Syntax: {{variableName}} will be replaced with this.variables['variableName']
   * @param {string} text - Text to process
   * @returns {string} - Text with variables replaced
   */
  replaceVariables(text) {
    if (!text) return text;
    if (typeof text !== 'string') return text;
    
    return text.replace(/\{\{(\w+)\}\}/g, (match, varName) => {
      if (this.variables.hasOwnProperty(varName)) {
        return String(this.variables[varName]);
      }
      // If variable not found, keep the original placeholder
      console.warn(`Variable {{${varName}}} not found in execution context`);
      return match;
    });
  }

  async executeAutomation(automationData, executionId, progressCallback = null) {
    if (this.isExecuting) {
      throw new Error('Another execution is in progress');
    }

    this.isExecuting = true;
    this.totalExecutions++;

    const executionDetails = [];
    const startTime = Date.now();

    // Set default stopOnFailure to true (same as PlaywrightRunner)
    const stopOnFailure = automationData.stopOnFailure !== false;

    try {
      // Launch browser
      await this.launchBrowser();

      const steps = automationData.steps || [];
      let passedSteps = 0;
      let failedSteps = 0;

      for (let i = 0; i < steps.length; i++) {
        const step = steps[i];
        const stepStartTime = Date.now();

        try {
          console.log(`[Executor] Executing step ${i + 1}/${steps.length}: ${step.action}`);

          const result = await this.executeStep(step, i);

          const stepDuration = Date.now() - stepStartTime;
          executionDetails.push({
            step_index: i,
            action: step.action,
            status: 'passed',
            duration: stepDuration,
            xpath: step.xpath,
            ...result
          });

          passedSteps++;

          // Send progress
          if (progressCallback) {
            progressCallback({
              currentStep: i + 1,
              totalSteps: steps.length,
              status: 'passed',
              message: `Step ${i + 1} passed`
            });
          }
        } catch (error) {
          const stepDuration = Date.now() - stepStartTime;
          const stepDetail = {
            step_index: i,
            action: step.action,
            status: 'failed',
            duration: stepDuration,
            error: error.message,
            xpath: step.xpath
          };

          // Capture error screenshot if screenshot capture is enabled
          try {
            const screenshotBuffer = await this.page.screenshot();
            const base64Screenshot = screenshotBuffer.toString('base64');
            stepDetail.errorScreenshot = base64Screenshot;
            stepDetail.errorScreenshotMimeType = 'image/png';
          } catch (e) {
            console.warn('[Executor] Failed to capture error screenshot:', e.message);
          }

          executionDetails.push(stepDetail);
          failedSteps++;

          // Send progress
          if (progressCallback) {
            progressCallback({
              currentStep: i + 1,
              totalSteps: steps.length,
              status: 'failed',
              message: `Step ${i + 1} failed: ${error.message}`
            });
          }

          // Stop on failure (default true, like PlaywrightRunner)
          if (stopOnFailure) {
            console.log(`[Executor] Stopping execution at step ${i + 1} (stopOnFailure enabled)`);
            break;
          }
        }
      }

      const totalDuration = Date.now() - startTime;
      const successRate = ((passedSteps / steps.length) * 100).toFixed(2);

      return {
        success: failedSteps === 0,
        executionId,
        summary: {
          total_steps: steps.length,
          passed_steps: passedSteps,
          failed_steps: failedSteps,
          success_rate: `${successRate}%`,
          total_duration: `${totalDuration}ms`,
          overall_status: failedSteps === 0 ? 'passed' : 'failed'
        },
        details: executionDetails
      };
    } catch (error) {
      console.error(`[Executor] Execution error:`, error);
      throw error;
    } finally {
      this.isExecuting = false;
      await this.closeBrowser();
    }
  }

  async executeStep(step, stepIndex) {
    // Apply variable substitution to step inputs
    const processedStep = {
      ...step,
      xpath: this.replaceVariables(step.xpath),
      value: this.replaceVariables(step.value),
      url: this.replaceVariables(step.url),
      text: this.replaceVariables(step.text),
      selector: this.replaceVariables(step.selector),
      frameSelector: this.replaceVariables(step.frameSelector),
      nestedFrameSelectors: this.replaceVariables(step.nestedFrameSelectors),
      saveTo: this.replaceVariables(step.saveTo),
      secondValue: this.replaceVariables(step.secondValue)
    };

    const { action, value, xpath, selector, url, text, key, delay, frameSelector, nestedFrameSelectors } = processedStep;
    const selectorTarget = xpath ? `xpath=${xpath}` : selector;

    // Validate action
    if (!action) {
      throw new Error(`Step ${stepIndex}: action is required`);
    }

    // Log step details for debugging
    console.log(`[Executor] Step ${stepIndex + 1}: action=${action}, xpath=${xpath || 'N/A'}, selector=${selector || 'N/A'}`);

    switch (action.toLowerCase()) {
      case 'navigate':
      case 'goto':
        if (!url && !value) {
          throw new Error(`navigate action requires url or value. Got url="${url}", value="${value}"`);
        }
        try {
          const targetUrl = url || value;
          console.log(`[Executor] Navigating to: ${targetUrl}`);
          await this.page.goto(targetUrl, { 
            waitUntil: 'load',
            timeout: this.timeoutMs
          });
        } catch (error) {
          if (error.message.includes('Timeout')) {
            console.warn(`Navigation timeout with 'load', retrying with 'domcontentloaded'...`);
            await this.page.goto(url || value, { 
              waitUntil: 'domcontentloaded',
              timeout: this.timeoutMs
            });
          } else {
            throw new Error(`Failed to navigate to ${url || value}: ${error.message}`);
          }
        }
        return { message: `Navigated to ${url || value}` };

      case 'click':
        if (!selectorTarget) {
          throw new Error(`click action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          await this.page.click(selectorTarget, { timeout: this.timeoutMs });
        } catch (error) {
          throw new Error(`Failed to click element (${selectorTarget}): ${error.message}`);
        }
        return { message: 'Clicked element' };

      case 'doubleclick':
      case 'dblclick':
        if (!selectorTarget) throw new Error('doubleclick action requires xpath or selector');
        await this.page.dblclick(selectorTarget);
        return { message: 'Double-clicked element' };

      case 'fill':
        if (!selectorTarget) {
          throw new Error(`fill action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          await this.page.fill(selectorTarget, value || text || '', { timeout: this.timeoutMs });
        } catch (error) {
          throw new Error(`Failed to fill element (${selectorTarget}): ${error.message}`);
        }
        return { message: `Filled with text: ${value || text}` };

      case 'type':
        if (!selectorTarget) {
          throw new Error(`type action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          // Clear field first using fill (reliable method for controlled inputs)
          await this.page.fill(selectorTarget, '', { timeout: this.timeoutMs });
          // Wait for onChange event to settle before typing
          await this.page.waitForTimeout(100);
          // Type to trigger input events (important for event handlers, validation, etc)
          await this.page.type(selectorTarget, value || text || '', { delay: delay || 50, timeout: this.timeoutMs });
          // Wait for autocomplete/dropdown to settle if any
          await this.page.waitForTimeout(50);
        } catch (error) {
          throw new Error(`Failed to type text in element (${selectorTarget}): ${error.message}`);
        }
        return { message: `Typed text: ${value || text}` };

      case 'press':
        if (!selectorTarget) throw new Error('press action requires xpath or selector');
        await this.page.press(selectorTarget, key || value);
        return { message: `Pressed key: ${key || value}` };

      case 'hover':
        if (!selectorTarget) throw new Error('hover action requires xpath or selector');
        await this.page.hover(selectorTarget);
        return { message: 'Hovered over element' };

      case 'select':
        if (!selectorTarget) throw new Error('select action requires xpath or selector');
        await this.page.selectOption(selectorTarget, value);
        return { message: `Selected option: ${value}` };

      case 'screenshot':
        try {
          // Capture screenshot as buffer instead of saving to disk (for Vercel compatibility)
          const screenshotBuffer = await this.page.screenshot();
          const base64Screenshot = screenshotBuffer.toString('base64');
          const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
          const filename = value || `screenshot-${stepIndex}-${timestamp}.png`;
          return { 
            message: `Screenshot captured`, 
            screenshot: base64Screenshot,
            filename: filename,
            mimeType: 'image/png'
          };
        } catch (error) {
          throw new Error(`Failed to take screenshot: ${error.message}`);
        }

      case 'pressenter':
      case 'pressEnter':
        if (!selectorTarget) throw new Error('pressEnter action requires xpath or selector');
        await this.page.press(selectorTarget, 'Enter');
        return { message: 'Pressed Enter key' };

      case 'pressenterinframe':
      case 'pressEnterInFrame':
        if (!selectorTarget) throw new Error('pressEnterInFrame action requires xpath or selector');
        if (!frameSelector) throw new Error('pressEnterInFrame action requires frameSelector');
        {
          const frameLocator = this.page.frameLocator(frameSelector);
          await frameLocator.locator(selectorTarget).press('Enter');
        }
        return { message: 'Pressed Enter key in frame' };

      case 'pressenterinnestedframe':
      case 'pressEnterInNestedFrame':
        if (!selectorTarget) throw new Error('pressEnterInNestedFrame action requires xpath or selector');
        if (!nestedFrameSelectors) throw new Error('pressEnterInNestedFrame action requires nestedFrameSelectors');
        {
          const frameList = nestedFrameSelectors.split(',').map(s => s.trim());
          let frameLocator = this.page.frameLocator(frameList[0]);
          for (let i = 1; i < frameList.length; i++) {
            frameLocator = frameLocator.frameLocator(frameList[i]);
          }
          await frameLocator.locator(selectorTarget).press('Enter');
        }
        return { message: 'Pressed Enter key in nested frame' };

      case 'wait':
      case 'pause':
        let waitTime = value || delay || 1000;
        // Convert to number and handle both seconds and milliseconds
        waitTime = parseInt(waitTime);
        // If value is less than 100, assume it's in seconds, convert to milliseconds
        if (waitTime < 100) {
          waitTime = waitTime * 1000;
        }
        console.log(`[Executor] Waiting for ${waitTime}ms`);
        await this.page.waitForTimeout(waitTime);
        return { message: `Waited ${waitTime}ms (${(waitTime / 1000).toFixed(3)}s)` };

      case 'wait_for_selector':
      case 'waitelement':
      case 'waitElement':
        if (!selectorTarget) throw new Error('waitElement action requires xpath or selector');
        await this.page.waitForSelector(selectorTarget, { timeout: this.timeoutMs });
        return { message: 'Element appeared' };

      case 'assertvisible':
      case 'assert_visible':
      case 'check':
        if (!selectorTarget) {
          throw new Error(`assertVisible action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          const isVisible = await this.page.isVisible(selectorTarget, { timeout: this.timeoutMs });
          if (!isVisible) {
            throw new Error(`Element not visible with selector: ${selectorTarget}`);
          }
        } catch (error) {
          throw new Error(`assertVisible failed for ${selectorTarget}: ${error.message}`);
        }
        return { message: 'Element is visible' };

      case 'assertnotvisible':
      case 'assert_not_visible':
        if (!selectorTarget) {
          throw new Error(`assertNotVisible action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          const isNotVisible = await this.page.isHidden(selectorTarget, { timeout: this.timeoutMs });
          if (!isNotVisible) {
            throw new Error(`Element should not be visible with selector: ${selectorTarget}`);
          }
        } catch (error) {
          throw new Error(`assertNotVisible failed for ${selectorTarget}: ${error.message}`);
        }
        return { message: 'Element is not visible' };

      case 'asserttext':
      case 'assert_text':
        if (!selectorTarget) {
          throw new Error(`assertText action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          const elementText = await this.page.textContent(selectorTarget, { timeout: this.timeoutMs });
          const expectedText = value || text;
          if (!elementText || !elementText.includes(expectedText)) {
            throw new Error(`Expected text "${expectedText}" not found in element. Got: "${elementText}"`);
          }
        } catch (error) {
          throw new Error(`assertText failed for ${selectorTarget}: ${error.message}`);
        }
        return { message: `Text "${value || text}" found on element` };

      case 'assertnotcontain':
      case 'assert_not_contain':
      case 'assertNotContain':
        if (!selectorTarget) {
          throw new Error(`assertNotContain action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          const elementText = await this.page.textContent(selectorTarget, { timeout: this.timeoutMs });
          const notExpectedText = value || text;
          if (elementText && elementText.includes(notExpectedText)) {
            throw new Error(`Expected text NOT to contain "${notExpectedText}", but it did. Got: "${elementText}"`);
          }
        } catch (error) {
          throw new Error(`assertNotContain failed for ${selectorTarget}: ${error.message}`);
        }
        return { message: `Text does NOT contain "${value || text}"` };

      case 'asserttobe':
      case 'assertToBe':
        if (!value) {
          throw new Error('assertToBe action requires value (first value)');
        }
        if (!processedStep.secondValue) {
          throw new Error('assertToBe action requires secondValue (second value)');
        }
        if (value !== processedStep.secondValue) {
          throw new Error(`Assertion failed: "${value}" is not equal to "${processedStep.secondValue}"`);
        }
        return { message: `Assertion passed: "${value}" equals "${processedStep.secondValue}"` };

      case 'assertvaluecontain':
      case 'assertValueContain':
        if (!value) {
          throw new Error('assertValueContain action requires value (first value)');
        }
        if (!processedStep.secondValue) {
          throw new Error('assertValueContain action requires secondValue (substring to find)');
        }
        if (!String(value).includes(String(processedStep.secondValue))) {
          throw new Error(`Expected value "${value}" to contain "${processedStep.secondValue}", but it did not`);
        }
        return { message: `Assertion passed: "${value}" contains "${processedStep.secondValue}"` };

      case 'assertvaluenotcontain':
      case 'assertValueNotContain':
        if (!value) {
          throw new Error('assertValueNotContain action requires value (first value)');
        }
        if (!processedStep.secondValue) {
          throw new Error('assertValueNotContain action requires secondValue (substring to NOT find)');
        }
        if (String(value).includes(String(processedStep.secondValue))) {
          throw new Error(`Expected value "${value}" NOT to contain "${processedStep.secondValue}", but it did`);
        }
        return { message: `Assertion passed: "${value}" does NOT contain "${processedStep.secondValue}"` };

      case 'getcontent':
      case 'getContent':
        if (!selectorTarget) throw new Error('getContent action requires xpath or selector');
        const content = await this.page.textContent(selectorTarget);
        // Capture to variable if saveTo is specified
        if (processedStep.saveTo) {
          this.variables[processedStep.saveTo] = content;
        }
        return { message: 'Content retrieved', content };

      case 'gettextat':
      case 'getTextAt':
        if (!selectorTarget) throw new Error('getTextAt action requires xpath or selector');
        if (!value) throw new Error('getTextAt action requires value (first or last)');
        const locator = this.page.locator(selectorTarget);
        const textAtLocator = value.toLowerCase() === 'last' ? locator.last() : locator.first();
        const textAt = await textAtLocator.textContent();
        // Capture to variable if saveTo is specified
        if (processedStep.saveTo) {
          this.variables[processedStep.saveTo] = textAt;
        }
        return { message: 'Text At retrieved', textAt };

      case 'getvalue':
      case 'getValue':
        if (!selectorTarget) throw new Error('getValue action requires xpath or selector');
        const inputValue = await this.page.inputValue(selectorTarget);
        // Capture to variable if saveTo is specified
        if (processedStep.saveTo) {
          this.variables[processedStep.saveTo] = inputValue;
        }
        return { message: 'Value retrieved', value: inputValue };

      // Conditional attribute actions
      case 'getattributewithcondition':
      case 'getAttributeWithCondition':
        if (!selectorTarget) throw new Error('getAttributeWithCondition requires xpath or selector');
        if (!value) throw new Error('getAttributeWithCondition requires value (expected attribute value)');
        const attrValue = await this.page.getAttribute(selectorTarget, step.attribute || '');
        const conditionMet = attrValue === value;
        return { 
          message: `Attribute check: ${step.attribute || ''} = ${attrValue}, expected: ${value}, result: ${conditionMet ? 'matched' : 'not matched'}`,
          attributeValue: attrValue,
          expected: value,
          matched: conditionMet
        };

      case 'clickwithforce':
      case 'clickWithForce':
        if (!selectorTarget) throw new Error('clickWithForce requires xpath or selector');
        try {
          await this.page.click(selectorTarget, { force: true, timeout: this.timeoutMs });
        } catch (error) {
          throw new Error(`Failed to click element with force (${selectorTarget}): ${error.message}`);
        }
        return { message: 'Clicked element with force' };

      case 'clickifvisible':
      case 'clickIfVisible':
        if (!selectorTarget) throw new Error('clickIfVisible requires xpath or selector');
        if (!value) throw new Error('clickIfVisible requires value (true=click if visible, false=click if hidden)');
        // value can be 'true' (click if visible) or 'false' (click if not visible)
        const clickWhenVisible = (value === 'false' || value === false) ? false : true;
        try {
          const isVisibleForClick = await this.page.isVisible(selectorTarget, { timeout: this.timeoutMs });
          const shouldClick = clickWhenVisible ? isVisibleForClick : !isVisibleForClick;
          if (shouldClick) {
            await this.page.click(selectorTarget, { timeout: this.timeoutMs });
            return { 
              message: `Element ${clickWhenVisible ? 'is visible' : 'is not visible'}, clicked successfully`,
              clicked: true,
              visible: isVisibleForClick
            };
          } else {
            return { 
              message: `Element ${clickWhenVisible ? 'is not visible' : 'is visible'}, skip clicking`,
              clicked: false,
              visible: isVisibleForClick
            };
          }
        } catch (error) {
          throw new Error(`Failed to check visibility or click element (${selectorTarget}): ${error.message}`);
        }

      case 'clickifvisibleinframe':
      case 'clickIfVisibleInFrame':
        if (!frameSelector) throw new Error('clickIfVisibleInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('clickIfVisibleInFrame requires xpath or selector');
        if (!value) throw new Error('clickIfVisibleInFrame requires value (true=click if visible, false=click if hidden)');
        try {
          const clickWhenVisibleFrame = (value === 'false' || value === false) ? false : true;
          const isVisibleInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isVisible();
          const shouldClickFrame = clickWhenVisibleFrame ? isVisibleInFrame : !isVisibleInFrame;
          if (shouldClickFrame) {
            await this.page.frameLocator(frameSelector).locator(selectorTarget).click({ timeout: this.timeoutMs });
            return { 
              message: `Element in frame ${clickWhenVisibleFrame ? 'is visible' : 'is not visible'}, clicked successfully`,
              clicked: true,
              visible: isVisibleInFrame
            };
          } else {
            return { 
              message: `Element in frame ${clickWhenVisibleFrame ? 'is not visible' : 'is visible'}, skip clicking`,
              clicked: false,
              visible: isVisibleInFrame
            };
          }
        } catch (error) {
          throw new Error(`Failed to check visibility or click element in frame (${selectorTarget}): ${error.message}`);
        }

      case 'clickifvisibleinnestedframe':
      case 'clickIfVisibleInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('clickIfVisibleInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('clickIfVisibleInNestedFrame requires xpath or selector');
        if (!value) throw new Error('clickIfVisibleInNestedFrame requires value (true=click if visible, false=click if hidden)');
        try {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const clickWhenVisibleNested = (value === 'false' || value === false) ? false : true;
          const isVisibleInNested = await frameLocator.locator(selectorTarget).isVisible();
          const shouldClickNested = clickWhenVisibleNested ? isVisibleInNested : !isVisibleInNested;
          if (shouldClickNested) {
            await frameLocator.locator(selectorTarget).click({ timeout: this.timeoutMs });
            return { 
              message: `Element in nested frame ${clickWhenVisibleNested ? 'is visible' : 'is not visible'}, clicked successfully`,
              clicked: true,
              visible: isVisibleInNested
            };
          } else {
            return { 
              message: `Element in nested frame ${clickWhenVisibleNested ? 'is not visible' : 'is visible'}, skip clicking`,
              clicked: false,
              visible: isVisibleInNested
            };
          }
        } catch (error) {
          throw new Error(`Failed to check visibility or click element in nested frame (${selectorTarget}): ${error.message}`);
        }

      case 'clickifattributeequals':
      case 'clickIfAttributeEquals':
        if (!selectorTarget) throw new Error('clickIfAttributeEquals requires xpath or selector');
        if (!value) throw new Error('clickIfAttributeEquals requires value (expected attribute value)');
        const attrToCheck = await this.page.getAttribute(selectorTarget, step.attribute || '');
        if (attrToCheck === value) {
          try {
            await this.page.click(selectorTarget, { force: true, timeout: this.timeoutMs });
          } catch (error) {
            throw new Error(`Failed to click element (${selectorTarget}): ${error.message}`);
          }
          return { 
            message: `Attribute matched (${step.attribute || ''} = ${value}), element clicked`,
            clicked: true,
            attributeValue: attrToCheck
          };
        } else {
          return { 
            message: `Attribute not matched (${step.attribute || ''} = ${attrToCheck}, expected: ${value}), element not clicked`,
            clicked: false,
            attributeValue: attrToCheck
          };
        }

      // Frame locator actions
      case 'clickinframe':
      case 'clickInFrame':
        if (!frameSelector) throw new Error('clickInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('clickInFrame requires xpath or selector');
        try {
          await this.page.frameLocator(frameSelector).locator(selectorTarget).click({ timeout: this.timeoutMs });
        } catch (error) {
          throw new Error(`Failed to click element in frame ${frameSelector} with selector ${selectorTarget}: ${error.message}`);
        }
        return { message: 'Clicked element in frame' };

      case 'fillinframe':
      case 'fillInFrame':
        if (!frameSelector) throw new Error('fillInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('fillInFrame requires xpath or selector');
        const frame2 = this.page.frameLocator(frameSelector);
        const frameElementFill = frame2.locator(selectorTarget);
        // Wait for element to be visible
        await frameElementFill.waitFor({ state: 'visible', timeout: this.timeoutMs });
        // Fill value directly (fast, no event triggers)
        await frameElementFill.fill(value || '');
        return { message: `Filled element in frame: ${value}` };

      case 'typeinframe':
      case 'typeInFrame':
        if (!frameSelector) throw new Error('typeInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('typeInFrame requires xpath or selector');
        const frame2b = this.page.frameLocator(frameSelector);
        const frameElement2b = frame2b.locator(selectorTarget);
        // Wait for element to be visible and enabled
        await frameElement2b.waitFor({ state: 'visible', timeout: this.timeoutMs });
        // Clear field first using fill (reliable method for controlled inputs)
        await frameElement2b.fill('');
        // Wait for onChange event to settle before typing
        await this.page.waitForTimeout(100);
        // Type value to trigger input events
        await frameElement2b.type(value || '', { delay: 50 });
        // Wait for autocomplete/dropdown to settle if any
        await this.page.waitForTimeout(50);
        return { message: `Typed in frame: ${value}` };

      case 'gettextinframe':
      case 'getTextInFrame':
        if (!frameSelector) throw new Error('getTextInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('getTextInFrame requires xpath or selector');
        const textInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).textContent();
        // Capture to variable if saveTo is specified
        if (processedStep.saveTo) {
          this.variables[processedStep.saveTo] = textInFrame;
        }
        return { message: 'Text retrieved from frame', content: textInFrame };

      case 'gettextatinframe':
      case 'getTextAtInFrame':
        if (!frameSelector) throw new Error('getTextAtInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('getTextAtInFrame requires xpath or selector');
        if (!value) throw new Error('getTextAtInFrame requires value (first or last)');
        const locatorInFrame = this.page.frameLocator(frameSelector).locator(selectorTarget);
        const textAtInFrameLocator = value.toLowerCase() === 'last' ? locatorInFrame.last() : locatorInFrame.first();
        const textAtInFrame = await textAtInFrameLocator.textContent();
        // Capture to variable if saveTo is specified
        if (processedStep.saveTo) {
          this.variables[processedStep.saveTo] = textAtInFrame;
        }
        return { message: 'Text At retrieved from frame', content: textAtInFrame };

      // Conditional attribute actions in frame
      case 'getattributewithconditioninframe':
      case 'getAttributeWithConditionInFrame':
        if (!frameSelector) throw new Error('getAttributeWithConditionInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('getAttributeWithConditionInFrame requires xpath or selector');
        if (!value) throw new Error('getAttributeWithConditionInFrame requires value (expected attribute value)');
        const attrValueInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).getAttribute(step.attribute || '');
        const conditionMetInFrame = attrValueInFrame === value;
        return { 
          message: `Attribute check in frame: ${step.attribute || 'aria-checked'} = ${attrValueInFrame}, expected: ${value}, result: ${conditionMetInFrame ? 'matched' : 'not matched'}`,
          attributeValue: attrValueInFrame,
          expected: value,
          matched: conditionMetInFrame
        };

      case 'clickwithforceinframe':
      case 'clickWithForceInFrame':
        if (!frameSelector) throw new Error('clickWithForceInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('clickWithForceInFrame requires xpath or selector');
        try {
          await this.page.frameLocator(frameSelector).locator(selectorTarget).click({ force: true, timeout: this.timeoutMs });
        } catch (error) {
          throw new Error(`Failed to click element with force in frame ${frameSelector} with selector ${selectorTarget}: ${error.message}`);
        }
        return { message: 'Clicked element with force in frame' };

      case 'clickifattributeequalsinframe':
      case 'clickIfAttributeEqualsInFrame':
        if (!frameSelector) throw new Error('clickIfAttributeEqualsInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('clickIfAttributeEqualsInFrame requires xpath or selector');
        if (!value) throw new Error('clickIfAttributeEqualsInFrame requires value (expected attribute value)');
        const attrToCheckInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).getAttribute(step.attribute || '');
        if (attrToCheckInFrame === value) {
          try {
            await this.page.frameLocator(frameSelector).locator(selectorTarget).click({ force: true, timeout: this.timeoutMs });
          } catch (error) {
            throw new Error(`Failed to click element in frame (${selectorTarget}): ${error.message}`);
          }
          return { 
            message: `Attribute matched in frame (${step.attribute || ''} = ${value}), element clicked`,
            clicked: true,
            attributeValue: attrToCheckInFrame
          };
        } else {
          return { 
            message: `Attribute not matched in frame (${step.attribute || ''} = ${attrToCheckInFrame}, expected: ${value}), element not clicked`,
            clicked: false,
            attributeValue: attrToCheckInFrame
          };
        }

      case 'isvisibleinframe':
      case 'isVisibleInFrame':
        if (!frameSelector) throw new Error('isVisibleInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('isVisibleInFrame requires xpath or selector');
        const elementVisibleInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isVisible();
        if (!elementVisibleInFrame) {
          throw new Error(`Element not visible in frame: ${xpath || selector}`);
        }
        return { message: 'Element is visible in frame' };

      case 'assertvisibleinframe':
      case 'assertVisibleInFrame':
        if (!frameSelector) throw new Error('assertVisibleInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertVisibleInFrame requires xpath or selector');
        const isVisibleInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isVisible();
        if (!isVisibleInFrame) {
          throw new Error(`Element not visible in frame: ${xpath || selector}`);
        }
        return { message: 'Element is visible in frame' };

      case 'assertnotvisibleinframe':
      case 'assertNotVisibleInFrame':
        if (!frameSelector) throw new Error('assertNotVisibleInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertNotVisibleInFrame requires xpath or selector');
        const isNotVisibleInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isHidden();
        if (!isNotVisibleInFrame) {
          throw new Error(`Element should not be visible in frame: ${xpath || selector}`);
        }
        return { message: 'Element is not visible in frame' };

      case 'asserttextinframe':
      case 'assertTextInFrame':
        if (!frameSelector) throw new Error('assertTextInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertTextInFrame requires xpath or selector');
        const textContent = await this.page.frameLocator(frameSelector).locator(selectorTarget).textContent();
        if (!textContent || !textContent.includes(value || text)) {
          throw new Error(`Expected text "${value || text}" not found in frame. Got: "${textContent}"`);
        }
        return { message: `Text "${value || text}" found in frame` };

      case 'assertnotcontaininframe':
      case 'assertNotContainInFrame':
        if (!frameSelector) throw new Error('assertNotContainInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertNotContainInFrame requires xpath or selector');
        const textContentInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).textContent();
        if (textContentInFrame && textContentInFrame.includes(value || text)) {
          throw new Error(`Expected text NOT to contain "${value || text}" in frame, but it did. Got: "${textContentInFrame}"`);
        }
        return { message: `Text does NOT contain "${value || text}" in frame` };

      case 'assertcheckedinframe':
      case 'assertCheckedInFrame':
        if (!frameSelector) throw new Error('assertCheckedInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertCheckedInFrame requires xpath or selector');
        const isCheckedInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isChecked();
        if (!isCheckedInFrame) {
          throw new Error(`Element not checked in frame: ${xpath || selector}`);
        }
        return { message: 'Element is checked in frame' };

      case 'assertdisabledinframe':
      case 'assertDisabledInFrame':
        if (!frameSelector) throw new Error('assertDisabledInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertDisabledInFrame requires xpath or selector');
        const isDisabledInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isDisabled();
        if (!isDisabledInFrame) {
          throw new Error(`Element not disabled in frame: ${xpath || selector}`);
        }
        return { message: 'Element is disabled in frame' };

      // Nested frame locator actions
      case 'clickinnestedframe':
      case 'clickInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('clickInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('clickInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          await frameLocator.locator(selectorTarget).click();
        }
        return { message: 'Clicked element in nested frame' };

      case 'fillinnestedframe':
      case 'fillInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('fillInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('fillInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const element = frameLocator.locator(selectorTarget);
          await element.waitFor({ state: 'visible', timeout: this.timeoutMs });
          await element.fill(value || '');
        }
        return { message: `Filled element in nested frame: ${value}` };

      case 'typeinnestedframe':
      case 'typeInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('typeInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('typeInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const element = frameLocator.locator(selectorTarget);
          await element.waitFor({ state: 'visible', timeout: this.timeoutMs });
          // Clear field first using fill (reliable method for controlled inputs)
          await element.fill('');
          // Wait for onChange event to settle before typing
          await this.page.waitForTimeout(100);
          // Type value to trigger input events
          await element.type(value || '', { delay: 50 });
          // Wait for autocomplete/dropdown to settle if any
          await this.page.waitForTimeout(50);
        }
        return { message: `Typed in nested frame: ${value}` };

      case 'gettextinnestedframe':
      case 'getTextInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('getTextInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('getTextInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const textInNestedFrame = await frameLocator.locator(selectorTarget).textContent();
          // Capture to variable if saveTo is specified
          if (processedStep.saveTo) {
            this.variables[processedStep.saveTo] = textInNestedFrame;
          }
          return { message: 'Text retrieved from nested frame', content: textInNestedFrame };
        }

      case 'gettextatinnestedframe':
      case 'getTextAtInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('getTextAtInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('getTextAtInNestedFrame requires xpath or selector');
        if (!value) throw new Error('getTextAtInNestedFrame requires value (first or last)');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const locatorInNestedFrame = frameLocator.locator(selectorTarget);
          const textAtInNestedFrameLocator = value.toLowerCase() === 'last' ? locatorInNestedFrame.last() : locatorInNestedFrame.first();
          const textAtInNestedFrame = await textAtInNestedFrameLocator.textContent();
          // Capture to variable if saveTo is specified
          if (processedStep.saveTo) {
            this.variables[processedStep.saveTo] = textAtInNestedFrame;
          }
          return { message: 'Text At retrieved from nested frame', content: textAtInNestedFrame };
        }

      case 'isvisibleinnestedframe':
      case 'isVisibleInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('isVisibleInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('isVisibleInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const elementVisibleInNestedFrame = await frameLocator.locator(selectorTarget).isVisible();
          if (!elementVisibleInNestedFrame) {
            throw new Error(`Element not visible in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is visible in nested frame' };

      case 'assertvisibleinnestedframe':
      case 'assertVisibleInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertVisibleInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertVisibleInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const isVisibleInNestedFrame = await frameLocator.locator(selectorTarget).isVisible();
          if (!isVisibleInNestedFrame) {
            throw new Error(`Element not visible in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is visible in nested frame' };

      case 'assertnotvisibleinnestedframe':
      case 'assertNotVisibleInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertNotVisibleInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertNotVisibleInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const isNotVisibleInNestedFrame = await frameLocator.locator(selectorTarget).isHidden();
          if (!isNotVisibleInNestedFrame) {
            throw new Error(`Element should not be visible in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is not visible in nested frame' };

      case 'asserttextinnestedframe':
      case 'assertTextInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertTextInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertTextInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const textContentInNestedFrame = await frameLocator.locator(selectorTarget).textContent();
          if (!textContentInNestedFrame || !textContentInNestedFrame.includes(value)) {
            throw new Error(`Expected text "${value}" not found in nested frame. Got: "${textContentInNestedFrame}"`);
          }
        }
        return { message: `Text "${value}" found in nested frame` };

      case 'assertnotcontaininnestedframe':
      case 'assertNotContainInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertNotContainInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertNotContainInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const textContentInNestedFrameNotContain = await frameLocator.locator(selectorTarget).textContent();
          if (textContentInNestedFrameNotContain && textContentInNestedFrameNotContain.includes(value)) {
            throw new Error(`Expected text NOT to contain "${value}" in nested frame, but it did. Got: "${textContentInNestedFrameNotContain}"`);
          }
        }
        return { message: `Text does NOT contain "${value}" in nested frame` };

      case 'assertcheckedinnestedframe':
      case 'assertCheckedInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertCheckedInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertCheckedInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const isCheckedInNestedFrame = await frameLocator.locator(selectorTarget).isChecked();
          if (!isCheckedInNestedFrame) {
            throw new Error(`Element not checked in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is checked in nested frame' };

      case 'assertdisabledinnestedframe':
      case 'assertDisabledInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertDisabledInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertDisabledInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const isDisabledInNestedFrame = await frameLocator.locator(selectorTarget).isDisabled();
          if (!isDisabledInNestedFrame) {
            throw new Error(`Element not disabled in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is disabled in nested frame' };

      // Conditional attribute actions in nested frame
      case 'getattributewithconditioninnestedframe':
      case 'getAttributeWithConditionInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('getAttributeWithConditionInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('getAttributeWithConditionInNestedFrame requires xpath or selector');
        if (!value) throw new Error('getAttributeWithConditionInNestedFrame requires value (expected attribute value)');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const attrValueInNestedFrame = await frameLocator.locator(selectorTarget).getAttribute(step.attribute || '');
          const conditionMetInNestedFrame = attrValueInNestedFrame === value;
          return { 
            message: `Attribute check in nested frame: ${step.attribute || ''} = ${attrValueInNestedFrame}, expected: ${value}, result: ${conditionMetInNestedFrame ? 'matched' : 'not matched'}`,
            attributeValue: attrValueInNestedFrame,
            expected: value,
            matched: conditionMetInNestedFrame
          };
        }

      case 'clickwithforceinnestedframe':
      case 'clickWithForceInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('clickWithForceInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('clickWithForceInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          try {
            await frameLocator.locator(selectorTarget).click({ force: true, timeout: this.timeoutMs });
          } catch (error) {
            throw new Error(`Failed to click element with force in nested frame with selector ${selectorTarget}: ${error.message}`);
          }
        }
        return { message: 'Clicked element with force in nested frame' };

      case 'clickifattributeequalsinnestedframe':
      case 'clickIfAttributeEqualsInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('clickIfAttributeEqualsInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('clickIfAttributeEqualsInNestedFrame requires xpath or selector');
        if (!value) throw new Error('clickIfAttributeEqualsInNestedFrame requires value (expected attribute value)');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const attrToCheckInNestedFrame = await frameLocator.locator(selectorTarget).getAttribute(step.attribute || '');
          if (attrToCheckInNestedFrame === value) {
            try {
              await frameLocator.locator(selectorTarget).click({ force: true, timeout: this.timeoutMs });
            } catch (error) {
              throw new Error(`Failed to click element in nested frame (${selectorTarget}): ${error.message}`);
            }
            return { 
              message: `Attribute matched in nested frame (${step.attribute || ''} = ${value}), element clicked`,
              clicked: true,
              attributeValue: attrToCheckInNestedFrame
            };
          } else {
            return { 
              message: `Attribute not matched in nested frame (${step.attribute || ''} = ${attrToCheckInNestedFrame}, expected: ${value}), element not clicked`,
              clicked: false,
              attributeValue: attrToCheckInNestedFrame
            };
          }
        }

      case 'newtab':
      case 'newTab':
        const newPage = await this.context.newPage();
        newPage.setDefaultTimeout(this.timeoutMs);
        this.pages.push(newPage);
        this.page = newPage;
        this.currentPageIndex = this.pages.length - 1;
        if (processedStep.value) {
          try {
            await newPage.goto(processedStep.value, { waitUntil: 'load', timeout: this.timeoutMs });
          } catch (error) {
            if (error.message.includes('Timeout')) {
              await newPage.goto(processedStep.value, { waitUntil: 'domcontentloaded', timeout: this.timeoutMs });
            }
          }
          return { status: 'passed', message: `New tab opened and navigated to ${processedStep.value}`, tabIndex: this.currentPageIndex, totalTabs: this.pages.length };
        }
        return { status: 'passed', message: 'New tab opened', tabIndex: this.currentPageIndex, totalTabs: this.pages.length };

      case 'switchtotab':
      case 'switchToTab':
        if (!processedStep.value) throw new Error('switchToTab requires value (tab index)');
        const tabIndex = parseInt(processedStep.value);
        if (isNaN(tabIndex) || tabIndex < 0 || tabIndex >= this.pages.length) {
          throw new Error(`Invalid tab index: ${tabIndex}. Available tabs: 0-${this.pages.length - 1}`);
        }
        this.page = this.pages[tabIndex];
        this.currentPageIndex = tabIndex;
        return { status: 'passed', message: `Switched to tab ${tabIndex}`, tabIndex, totalTabs: this.pages.length };

      case 'closetab':
      case 'closeTab':
        if (this.pages.length <= 1) {
          throw new Error('Cannot close last tab');
        }
        await this.page.close();
        this.pages.splice(this.currentPageIndex, 1);
        this.currentPageIndex = Math.max(0, this.currentPageIndex - 1);
        this.page = this.pages[this.currentPageIndex];
        return { status: 'passed', message: `Tab closed. Now on tab ${this.currentPageIndex}`, tabIndex: this.currentPageIndex, totalTabs: this.pages.length };

      case 'newcontext':
      case 'newContext':
        const newContext = await this.browser.newContext();
        newContext.setDefaultTimeout(this.timeoutMs);
        this.contexts.push(newContext);
        this.context = newContext;
        this.currentContextIndex = this.contexts.length - 1;
        const contextPage = await newContext.newPage();
        contextPage.setDefaultTimeout(this.timeoutMs);
        this.pages = [contextPage];
        this.page = contextPage;
        this.currentPageIndex = 0;
        if (processedStep.value) {
          await contextPage.goto(processedStep.value, { waitUntil: 'networkidle' });
        }
        return { status: 'passed', message: 'New context created', contextIndex: this.currentContextIndex };

      case 'switchtocontext':
      case 'switchToContext':
        const contextIndex = parseInt(processedStep.value);
        if (isNaN(contextIndex) || contextIndex < 0 || contextIndex >= this.contexts.length) {
          throw new Error(`Invalid context index: ${processedStep.value}. Available contexts: 0-${this.contexts.length - 1}`);
        }
        this.context = this.contexts[contextIndex];
        this.currentContextIndex = contextIndex;
        const contextPageList = await this.context.pages();
        this.pages = contextPageList;
        this.page = contextPageList[0] || await this.context.newPage();
        this.currentPageIndex = 0;
        return { status: 'passed', message: `Switched to context ${contextIndex}` };

      case 'closecontext':
      case 'closeContext':
        const contextToCloseIndex = parseInt(processedStep.value);
        if (isNaN(contextToCloseIndex) || contextToCloseIndex < 0 || contextToCloseIndex >= this.contexts.length) {
          throw new Error(`Invalid context index: ${processedStep.value}. Available contexts: 0-${this.contexts.length - 1}`);
        }
        if (this.contexts.length === 1) {
          throw new Error('Cannot close the last context');
        }
        const contextToClose = this.contexts[contextToCloseIndex];
        await contextToClose.close();
        this.contexts.splice(contextToCloseIndex, 1);
        if (this.currentContextIndex >= this.contexts.length) {
          this.currentContextIndex = this.contexts.length - 1;
        }
        this.context = this.contexts[this.currentContextIndex];
        const contextPagesAfterClose = await this.context.pages();
        this.pages = contextPagesAfterClose;
        this.page = contextPagesAfterClose[0] || await this.context.newPage();
        this.currentPageIndex = 0;
        return { status: 'passed', message: `Context ${contextToCloseIndex} closed`, currentContextIndex: this.currentContextIndex };

      default:
        throw new Error(`Unknown action: ${action}`);
    }
  }

  async cleanup() {
    await this.closeBrowser();
  }

  getExecutionStatus() {
    return this.isExecuting;
  }

  getTotalExecutions() {
    return this.totalExecutions;
  }

  /**
   * Queue an execution untuk diproses secara sequential
   * Digunakan untuk batch execution
   */
  async queueExecution(automationData, executionId, progressCallback = null) {
    return new Promise((resolve, reject) => {
      this.executionQueue.push({
        automationData,
        executionId,
        progressCallback,
        resolve,
        reject
      });
      
      // Mulai process queue jika belum
      this.processQueue();
    });
  }

  /**
   * Process execution queue secara sequential
   */
  async processQueue() {
    if (this.isProcessingQueue || this.executionQueue.length === 0) {
      return;
    }

    this.isProcessingQueue = true;

    while (this.executionQueue.length > 0) {
      const { automationData, executionId, progressCallback, resolve, reject } = this.executionQueue.shift();

      try {
        const result = await this.executeAutomation(automationData, executionId, progressCallback);
        resolve(result);
      } catch (error) {
        reject(error);
      }
    }

    this.isProcessingQueue = false;
  }
}

