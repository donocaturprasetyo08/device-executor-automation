/**
 * PlaywrightExecutor - Execute automation steps menggunakan Playwright
 */

import { chromium } from 'playwright';
import { v4 as uuidv4 } from 'uuid';

export class PlaywrightExecutor {
  constructor(options = {}) {
    this.headless = options.headless === true; // Headless false by default (visible mode)
    this.timeoutMs = options.timeout || 30000;
    this.browser = null;
    this.page = null;
    this.context = null;
    this.isExecuting = false;
    this.totalExecutions = 0;
    this.chromiumPath = process.env.CHROME_PATH || null;
    this.variables = {}; // Store captured variables during execution
    
    // Execution queue untuk handle batch execution secara sequential
    this.executionQueue = [];
    this.isProcessingQueue = false;
  }

  async launchBrowser() {
    try {
      const launchOptions = {
        headless: this.headless
      };

      // Jika custom chromium path disediakan
      if (this.chromiumPath) {
        launchOptions.executablePath = this.chromiumPath;
      }

      this.browser = await chromium.launch(launchOptions);
      this.context = await this.browser.newContext();
      this.page = await this.context.newPage();
      this.page.setDefaultTimeout(this.timeoutMs);

      console.log(`[Executor] Browser launched successfully`);
      return true;
    } catch (error) {
      console.error(`[Executor] Failed to launch browser:`, error);
      throw error;
    }
  }

  async closeBrowser() {
    try {
      if (this.page) {
        await this.page.close();
      }
      if (this.context) {
        await this.context.close();
      }
      if (this.browser) {
        await this.browser.close();
      }
    } catch (error) {
      console.error(`[Executor] Error closing browser:`, error);
    }
  }

  /**
   * Replace variable placeholders in text with captured variable values
   * Syntax: {{variableName}} will be replaced with this.variables['variableName']
   * @param {string} text - Text to process
   * @returns {string} - Text with variables replaced
   */
  replaceVariables(text) {
    if (!text) return text;
    if (typeof text !== 'string') return text;
    
    return text.replace(/\{\{(\w+)\}\}/g, (match, varName) => {
      if (this.variables.hasOwnProperty(varName)) {
        return String(this.variables[varName]);
      }
      // If variable not found, keep the original placeholder
      console.warn(`Variable {{${varName}}} not found in execution context`);
      return match;
    });
  }

  async executeAutomation(automationData, executionId, progressCallback = null) {
    if (this.isExecuting) {
      throw new Error('Another execution is in progress');
    }

    this.isExecuting = true;
    this.totalExecutions++;

    const executionDetails = [];
    const startTime = Date.now();

    // Set default stopOnFailure to true (same as PlaywrightRunner)
    const stopOnFailure = automationData.stopOnFailure !== false;

    try {
      // Launch browser
      await this.launchBrowser();

      const steps = automationData.steps || [];
      let passedSteps = 0;
      let failedSteps = 0;

      for (let i = 0; i < steps.length; i++) {
        const step = steps[i];
        const stepStartTime = Date.now();

        try {
          console.log(`[Executor] Executing step ${i + 1}/${steps.length}: ${step.action}`);

          const result = await this.executeStep(step, i);

          const stepDuration = Date.now() - stepStartTime;
          executionDetails.push({
            step_index: i,
            action: step.action,
            status: 'passed',
            duration: stepDuration,
            xpath: step.xpath,
            ...result
          });

          passedSteps++;

          // Send progress
          if (progressCallback) {
            progressCallback({
              currentStep: i + 1,
              totalSteps: steps.length,
              status: 'passed',
              message: `Step ${i + 1} passed`
            });
          }
        } catch (error) {
          const stepDuration = Date.now() - stepStartTime;
          const stepDetail = {
            step_index: i,
            action: step.action,
            status: 'failed',
            duration: stepDuration,
            error: error.message,
            xpath: step.xpath
          };

          // Capture error screenshot if screenshot capture is enabled
          try {
            const screenshotBuffer = await this.page.screenshot();
            const base64Screenshot = screenshotBuffer.toString('base64');
            stepDetail.errorScreenshot = base64Screenshot;
            stepDetail.errorScreenshotMimeType = 'image/png';
          } catch (e) {
            console.warn('[Executor] Failed to capture error screenshot:', e.message);
          }

          executionDetails.push(stepDetail);
          failedSteps++;

          // Send progress
          if (progressCallback) {
            progressCallback({
              currentStep: i + 1,
              totalSteps: steps.length,
              status: 'failed',
              message: `Step ${i + 1} failed: ${error.message}`
            });
          }

          // Stop on failure (default true, like PlaywrightRunner)
          if (stopOnFailure) {
            console.log(`[Executor] Stopping execution at step ${i + 1} (stopOnFailure enabled)`);
            break;
          }
        }
      }

      const totalDuration = Date.now() - startTime;
      const successRate = ((passedSteps / steps.length) * 100).toFixed(2);

      return {
        success: failedSteps === 0,
        executionId,
        summary: {
          total_steps: steps.length,
          passed_steps: passedSteps,
          failed_steps: failedSteps,
          success_rate: `${successRate}%`,
          total_duration: `${totalDuration}ms`,
          overall_status: failedSteps === 0 ? 'passed' : 'failed'
        },
        details: executionDetails
      };
    } catch (error) {
      console.error(`[Executor] Execution error:`, error);
      throw error;
    } finally {
      this.isExecuting = false;
      await this.closeBrowser();
    }
  }

  async executeStep(step, stepIndex) {
    // Apply variable substitution to step inputs
    const processedStep = {
      ...step,
      xpath: this.replaceVariables(step.xpath),
      value: this.replaceVariables(step.value),
      url: this.replaceVariables(step.url),
      text: this.replaceVariables(step.text),
      selector: this.replaceVariables(step.selector),
      frameSelector: this.replaceVariables(step.frameSelector),
      nestedFrameSelectors: this.replaceVariables(step.nestedFrameSelectors)
    };

    const { action, value, xpath, selector, url, text, key, delay, frameSelector, nestedFrameSelectors } = processedStep;
    const selectorTarget = xpath ? `xpath=${xpath}` : selector;

    // Validate action
    if (!action) {
      throw new Error(`Step ${stepIndex}: action is required`);
    }

    // Log step details for debugging
    console.log(`[Executor] Step ${stepIndex + 1}: action=${action}, xpath=${xpath || 'N/A'}, selector=${selector || 'N/A'}`);

    switch (action.toLowerCase()) {
      case 'navigate':
      case 'goto':
        if (!url && !value) {
          throw new Error(`navigate action requires url or value. Got url="${url}", value="${value}"`);
        }
        try {
          const targetUrl = url || value;
          console.log(`[Executor] Navigating to: ${targetUrl}`);
          await this.page.goto(targetUrl, { 
            waitUntil: 'load',
            timeout: this.timeoutMs
          });
        } catch (error) {
          if (error.message.includes('Timeout')) {
            console.warn(`Navigation timeout with 'load', retrying with 'domcontentloaded'...`);
            await this.page.goto(url || value, { 
              waitUntil: 'domcontentloaded',
              timeout: this.timeoutMs
            });
          } else {
            throw new Error(`Failed to navigate to ${url || value}: ${error.message}`);
          }
        }
        return { message: `Navigated to ${url || value}` };

      case 'click':
        if (!selectorTarget) {
          throw new Error(`click action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          await this.page.click(selectorTarget, { timeout: this.timeoutMs });
        } catch (error) {
          throw new Error(`Failed to click element (${selectorTarget}): ${error.message}`);
        }
        return { message: 'Clicked element' };

      case 'doubleclick':
      case 'dblclick':
        if (!selectorTarget) throw new Error('doubleclick action requires xpath or selector');
        await this.page.dblclick(selectorTarget);
        return { message: 'Double-clicked element' };

      case 'fill':
        if (!selectorTarget) {
          throw new Error(`fill action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          await this.page.fill(selectorTarget, value || text || '', { timeout: this.timeoutMs });
        } catch (error) {
          throw new Error(`Failed to fill element (${selectorTarget}): ${error.message}`);
        }
        return { message: `Filled with text: ${value || text}` };

      case 'type':
        if (!selectorTarget) {
          throw new Error(`type action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          // Clear field first using fill (reliable method for controlled inputs)
          await this.page.fill(selectorTarget, '', { timeout: this.timeoutMs });
          // Wait for onChange event to settle before typing
          await this.page.waitForTimeout(100);
          // Type to trigger input events (important for event handlers, validation, etc)
          await this.page.type(selectorTarget, value || text || '', { delay: delay || 50, timeout: this.timeoutMs });
          // Wait for autocomplete/dropdown to settle if any
          await this.page.waitForTimeout(50);
        } catch (error) {
          throw new Error(`Failed to type text in element (${selectorTarget}): ${error.message}`);
        }
        return { message: `Typed text: ${value || text}` };

      case 'press':
        if (!selectorTarget) throw new Error('press action requires xpath or selector');
        await this.page.press(selectorTarget, key || value);
        return { message: `Pressed key: ${key || value}` };

      case 'hover':
        if (!selectorTarget) throw new Error('hover action requires xpath or selector');
        await this.page.hover(selectorTarget);
        return { message: 'Hovered over element' };

      case 'select':
        if (!selectorTarget) throw new Error('select action requires xpath or selector');
        await this.page.selectOption(selectorTarget, value);
        return { message: `Selected option: ${value}` };

      case 'screenshot':
        try {
          // Capture screenshot as buffer instead of saving to disk (for Vercel compatibility)
          const screenshotBuffer = await this.page.screenshot();
          const base64Screenshot = screenshotBuffer.toString('base64');
          const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
          const filename = value || `screenshot-${stepIndex}-${timestamp}.png`;
          return { 
            message: `Screenshot captured`, 
            screenshot: base64Screenshot,
            filename: filename,
            mimeType: 'image/png'
          };
        } catch (error) {
          throw new Error(`Failed to take screenshot: ${error.message}`);
        }

      case 'wait':
      case 'pause':
        let waitTime = value || delay || 1000;
        // Convert to number and handle both seconds and milliseconds
        waitTime = parseInt(waitTime);
        // If value is less than 100, assume it's in seconds, convert to milliseconds
        if (waitTime < 100) {
          waitTime = waitTime * 1000;
        }
        console.log(`[Executor] Waiting for ${waitTime}ms`);
        await this.page.waitForTimeout(waitTime);
        return { message: `Waited ${waitTime}ms (${(waitTime / 1000).toFixed(3)}s)` };

      case 'wait_for_selector':
      case 'waitelement':
      case 'waitElement':
        if (!selectorTarget) throw new Error('waitElement action requires xpath or selector');
        await this.page.waitForSelector(selectorTarget, { timeout: this.timeoutMs });
        return { message: 'Element appeared' };

      case 'assertvisible':
      case 'assert_visible':
      case 'check':
        if (!selectorTarget) {
          throw new Error(`assertVisible action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          const isVisible = await this.page.isVisible(selectorTarget, { timeout: this.timeoutMs });
          if (!isVisible) {
            throw new Error(`Element not visible with selector: ${selectorTarget}`);
          }
        } catch (error) {
          throw new Error(`assertVisible failed for ${selectorTarget}: ${error.message}`);
        }
        return { message: 'Element is visible' };

      case 'assertnotvisible':
      case 'assert_not_visible':
        if (!selectorTarget) {
          throw new Error(`assertNotVisible action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          const isNotVisible = await this.page.isHidden(selectorTarget, { timeout: this.timeoutMs });
          if (!isNotVisible) {
            throw new Error(`Element should not be visible with selector: ${selectorTarget}`);
          }
        } catch (error) {
          throw new Error(`assertNotVisible failed for ${selectorTarget}: ${error.message}`);
        }
        return { message: 'Element is not visible' };

      case 'asserttext':
      case 'assert_text':
        if (!selectorTarget) {
          throw new Error(`assertText action requires xpath or selector. Got xpath="${xpath}", selector="${selector}"`);
        }
        try {
          const elementText = await this.page.textContent(selectorTarget, { timeout: this.timeoutMs });
          const expectedText = value || text;
          if (!elementText || !elementText.includes(expectedText)) {
            throw new Error(`Expected text "${expectedText}" not found in element. Got: "${elementText}"`);
          }
        } catch (error) {
          throw new Error(`assertText failed for ${selectorTarget}: ${error.message}`);
        }
        return { message: `Text "${value || text}" found on element` };

      case 'getcontent':
      case 'getContent':
        if (!selectorTarget) throw new Error('getContent action requires xpath or selector');
        const content = await this.page.textContent(selectorTarget);
        // Capture to variable if saveTo is specified
        if (step.saveTo) {
          this.variables[step.saveTo] = content;
        }
        return { message: 'Content retrieved', content };

      case 'getvalue':
      case 'getValue':
        if (!selectorTarget) throw new Error('getValue action requires xpath or selector');
        const inputValue = await this.page.inputValue(selectorTarget);
        // Capture to variable if saveTo is specified
        if (step.saveTo) {
          this.variables[step.saveTo] = inputValue;
        }
        return { message: 'Value retrieved', value: inputValue };

      // Frame locator actions
      case 'clickinframe':
      case 'clickInFrame':
        if (!frameSelector) throw new Error('clickInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('clickInFrame requires xpath or selector');
        try {
          await this.page.frameLocator(frameSelector).locator(selectorTarget).click({ timeout: this.timeoutMs });
        } catch (error) {
          throw new Error(`Failed to click element in frame ${frameSelector} with selector ${selectorTarget}: ${error.message}`);
        }
        return { message: 'Clicked element in frame' };

      case 'fillinframe':
      case 'fillInFrame':
        if (!frameSelector) throw new Error('fillInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('fillInFrame requires xpath or selector');
        const frame2 = this.page.frameLocator(frameSelector);
        const frameElementFill = frame2.locator(selectorTarget);
        // Wait for element to be visible
        await frameElementFill.waitFor({ state: 'visible', timeout: this.timeoutMs });
        // Fill value directly (fast, no event triggers)
        await frameElementFill.fill(value || '');
        return { message: `Filled element in frame: ${value}` };

      case 'typeinframe':
      case 'typeInFrame':
        if (!frameSelector) throw new Error('typeInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('typeInFrame requires xpath or selector');
        const frame2b = this.page.frameLocator(frameSelector);
        const frameElement2b = frame2b.locator(selectorTarget);
        // Wait for element to be visible and enabled
        await frameElement2b.waitFor({ state: 'visible', timeout: this.timeoutMs });
        // Clear field first using fill (reliable method for controlled inputs)
        await frameElement2b.fill('');
        // Wait for onChange event to settle before typing
        await this.page.waitForTimeout(100);
        // Type value to trigger input events
        await frameElement2b.type(value || '', { delay: 50 });
        // Wait for autocomplete/dropdown to settle if any
        await this.page.waitForTimeout(50);
        return { message: `Typed in frame: ${value}` };

      case 'gettextinframe':
      case 'getTextInFrame':
        if (!frameSelector) throw new Error('getTextInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('getTextInFrame requires xpath or selector');
        const textInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).textContent();
        // Capture to variable if saveTo is specified
        if (step.saveTo) {
          this.variables[step.saveTo] = textInFrame;
        }
        return { message: 'Text retrieved from frame', content: textInFrame };

      case 'isvisibleinframe':
      case 'isVisibleInFrame':
        if (!frameSelector) throw new Error('isVisibleInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('isVisibleInFrame requires xpath or selector');
        const elementVisibleInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isVisible();
        if (!elementVisibleInFrame) {
          throw new Error(`Element not visible in frame: ${xpath || selector}`);
        }
        return { message: 'Element is visible in frame' };

      case 'assertvisibleinframe':
      case 'assertVisibleInFrame':
        if (!frameSelector) throw new Error('assertVisibleInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertVisibleInFrame requires xpath or selector');
        const isVisibleInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isVisible();
        if (!isVisibleInFrame) {
          throw new Error(`Element not visible in frame: ${xpath || selector}`);
        }
        return { message: 'Element is visible in frame' };

      case 'assertnotvisibleinframe':
      case 'assertNotVisibleInFrame':
        if (!frameSelector) throw new Error('assertNotVisibleInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertNotVisibleInFrame requires xpath or selector');
        const isNotVisibleInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isHidden();
        if (!isNotVisibleInFrame) {
          throw new Error(`Element should not be visible in frame: ${xpath || selector}`);
        }
        return { message: 'Element is not visible in frame' };

      case 'asserttextinframe':
      case 'assertTextInFrame':
        if (!frameSelector) throw new Error('assertTextInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertTextInFrame requires xpath or selector');
        const textContent = await this.page.frameLocator(frameSelector).locator(selectorTarget).textContent();
        if (!textContent || !textContent.includes(value || text)) {
          throw new Error(`Expected text "${value || text}" not found in frame. Got: "${textContent}"`);
        }
        return { message: `Text "${value || text}" found in frame` };

      case 'assertcheckedinframe':
      case 'assertCheckedInFrame':
        if (!frameSelector) throw new Error('assertCheckedInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertCheckedInFrame requires xpath or selector');
        const isCheckedInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isChecked();
        if (!isCheckedInFrame) {
          throw new Error(`Element not checked in frame: ${xpath || selector}`);
        }
        return { message: 'Element is checked in frame' };

      case 'assertdisabledinframe':
      case 'assertDisabledInFrame':
        if (!frameSelector) throw new Error('assertDisabledInFrame requires frameSelector');
        if (!selectorTarget) throw new Error('assertDisabledInFrame requires xpath or selector');
        const isDisabledInFrame = await this.page.frameLocator(frameSelector).locator(selectorTarget).isDisabled();
        if (!isDisabledInFrame) {
          throw new Error(`Element not disabled in frame: ${xpath || selector}`);
        }
        return { message: 'Element is disabled in frame' };

      // Nested frame locator actions
      case 'clickinnestedframe':
      case 'clickInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('clickInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('clickInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          await frameLocator.locator(selectorTarget).click();
        }
        return { message: 'Clicked element in nested frame' };

      case 'fillinnestedframe':
      case 'fillInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('fillInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('fillInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const element = frameLocator.locator(selectorTarget);
          await element.waitFor({ state: 'visible', timeout: this.timeoutMs });
          await element.fill(value || '');
        }
        return { message: `Filled element in nested frame: ${value}` };

      case 'typeinnestedframe':
      case 'typeInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('typeInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('typeInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const element = frameLocator.locator(selectorTarget);
          await element.waitFor({ state: 'visible', timeout: this.timeoutMs });
          // Clear field first using fill (reliable method for controlled inputs)
          await element.fill('');
          // Wait for onChange event to settle before typing
          await this.page.waitForTimeout(100);
          // Type value to trigger input events
          await element.type(value || '', { delay: 50 });
          // Wait for autocomplete/dropdown to settle if any
          await this.page.waitForTimeout(50);
        }
        return { message: `Typed in nested frame: ${value}` };

      case 'gettextinnestedframe':
      case 'getTextInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('getTextInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('getTextInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const textInNestedFrame = await frameLocator.locator(selectorTarget).textContent();
          // Capture to variable if saveTo is specified
          if (step.saveTo) {
            this.variables[step.saveTo] = textInNestedFrame;
          }
          return { message: 'Text retrieved from nested frame', content: textInNestedFrame };
        }

      case 'isvisibleinnestedframe':
      case 'isVisibleInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('isVisibleInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('isVisibleInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const elementVisibleInNestedFrame = await frameLocator.locator(selectorTarget).isVisible();
          if (!elementVisibleInNestedFrame) {
            throw new Error(`Element not visible in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is visible in nested frame' };

      case 'assertvisibleinnestedframe':
      case 'assertVisibleInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertVisibleInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertVisibleInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const isVisibleInNestedFrame = await frameLocator.locator(selectorTarget).isVisible();
          if (!isVisibleInNestedFrame) {
            throw new Error(`Element not visible in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is visible in nested frame' };

      case 'assertnotvisibleinnestedframe':
      case 'assertNotVisibleInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertNotVisibleInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertNotVisibleInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const isNotVisibleInNestedFrame = await frameLocator.locator(selectorTarget).isHidden();
          if (!isNotVisibleInNestedFrame) {
            throw new Error(`Element should not be visible in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is not visible in nested frame' };

      case 'asserttextinnestedframe':
      case 'assertTextInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertTextInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertTextInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const textContentInNestedFrame = await frameLocator.locator(selectorTarget).textContent();
          if (!textContentInNestedFrame || !textContentInNestedFrame.includes(value)) {
            throw new Error(`Expected text "${value}" not found in nested frame. Got: "${textContentInNestedFrame}"`);
          }
        }
        return { message: `Text "${value}" found in nested frame` };

      case 'assertcheckedinnestedframe':
      case 'assertCheckedInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertCheckedInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertCheckedInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const isCheckedInNestedFrame = await frameLocator.locator(selectorTarget).isChecked();
          if (!isCheckedInNestedFrame) {
            throw new Error(`Element not checked in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is checked in nested frame' };

      case 'assertdisabledinnestedframe':
      case 'assertDisabledInNestedFrame':
        if (!nestedFrameSelectors) throw new Error('assertDisabledInNestedFrame requires nestedFrameSelectors');
        if (!selectorTarget) throw new Error('assertDisabledInNestedFrame requires xpath or selector');
        {
          const frameSelectors = typeof nestedFrameSelectors === 'string' 
            ? nestedFrameSelectors.split(',').map(s => s.trim())
            : nestedFrameSelectors;
          let frameLocator = this.page;
          for (const fs of frameSelectors) {
            frameLocator = frameLocator.frameLocator(fs);
          }
          const isDisabledInNestedFrame = await frameLocator.locator(selectorTarget).isDisabled();
          if (!isDisabledInNestedFrame) {
            throw new Error(`Element not disabled in nested frame: ${xpath || selector}`);
          }
        }
        return { message: 'Element is disabled in nested frame' };

      default:
        throw new Error(`Unknown action: ${action}`);
    }
  }

  async cleanup() {
    await this.closeBrowser();
  }

  getExecutionStatus() {
    return this.isExecuting;
  }

  getTotalExecutions() {
    return this.totalExecutions;
  }

  /**
   * Queue an execution untuk diproses secara sequential
   * Digunakan untuk batch execution
   */
  async queueExecution(automationData, executionId, progressCallback = null) {
    return new Promise((resolve, reject) => {
      this.executionQueue.push({
        automationData,
        executionId,
        progressCallback,
        resolve,
        reject
      });
      
      // Mulai process queue jika belum
      this.processQueue();
    });
  }

  /**
   * Process execution queue secara sequential
   */
  async processQueue() {
    if (this.isProcessingQueue || this.executionQueue.length === 0) {
      return;
    }

    this.isProcessingQueue = true;

    while (this.executionQueue.length > 0) {
      const { automationData, executionId, progressCallback, resolve, reject } = this.executionQueue.shift();

      try {
        const result = await this.executeAutomation(automationData, executionId, progressCallback);
        resolve(result);
      } catch (error) {
        reject(error);
      }
    }

    this.isProcessingQueue = false;
  }
}

