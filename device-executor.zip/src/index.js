/**
 * Device Executor - Main Entry Point
 * Menjalankan test automation di device lokal dengan Chrome/Chromium
 * Mendengarkan perintah dari backend via WebSocket atau REST API
 */

import 'dotenv/config';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';
import { DeviceExecutorManager } from './manager.js';
import { PlaywrightExecutor } from './executor.js';

const PORT = process.env.PORT || 3000;
const DEVICE_NAME = process.env.DEVICE_NAME || `device-${uuidv4().slice(0, 8)}`;
const DEVICE_TOKEN = process.env.DEVICE_TOKEN || uuidv4();
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:5000';
const USER_ID = process.env.USER_ID || null; // User yang memiliki device ini

// console.log(`[Device Executor] Starting device: ${DEVICE_NAME}`);
// console.log(`[Device Executor] Device Token: ${DEVICE_TOKEN}`);
// console.log(`[Device Executor] Backend URL: ${BACKEND_URL}`);
// console.log(`[Device Executor] Assigned to user: ${USER_ID || 'not assigned'}`);

// Initialize manager dan executor
const manager = new DeviceExecutorManager({
  deviceName: DEVICE_NAME,
  deviceToken: DEVICE_TOKEN,
  backendUrl: BACKEND_URL,
  userId: USER_ID // Pass userId ke manager
});

const executor = new PlaywrightExecutor();

// Create HTTP server untuk REST API fallback
const server = createServer((req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  if (req.url === '/health' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'ok',
      device_name: DEVICE_NAME,
      device_token: DEVICE_TOKEN,
      uptime: process.uptime()
    }));
    return;
  }

  if (req.url === '/status' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      device_name: DEVICE_NAME,
      status: manager.isConnected() ? 'connected' : 'disconnected',
      isExecuting: executor.getExecutionStatus(),
      totalExecutions: executor.getTotalExecutions()
    }));
    return;
  }

  // REST API untuk execute automation (fallback jika WebSocket gagal)
  if (req.url.startsWith('/execute') && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      try {
        const data = JSON.parse(body);
        console.log(`[HTTP] Received execution request for test case: ${data.testcase_id}`);
        console.log(`[HTTP] Steps count: ${data.steps?.length || 0}`);
        
        // Use executionId from backend if provided, otherwise generate new one
        const executionId = data.executionId || uuidv4();
        
        // Queue execution untuk handle batch sequentially
        executor.queueExecution(data, executionId)
          .then(result => {
            console.log(`[HTTP] Execution ${executionId} completed successfully`);
            console.log(`[HTTP] Reporting result with device_id: ${manager.getDeviceId()}`);
            manager.reportExecutionResult(executionId, result);
          })
          .catch(error => {
            console.error(`[HTTP] Execution ${executionId} failed:`, error.message);
            console.log(`[HTTP] Reporting error with device_id: ${manager.getDeviceId()}`);
            manager.reportExecutionError(executionId, error);
          });

        res.writeHead(202, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: true,
          executionId,
          message: 'Execution queued'
        }));
      } catch (error) {
        console.error(`[HTTP] Parse error:`, error);
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: error.message
        }));
      }
    });
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

// WebSocket Server untuk realtime communication
const wss = new WebSocketServer({ server });

wss.on('connection', (ws, req) => {
  console.log(`[WebSocket] New connection from ${req.socket.remoteAddress}`);

  // Kirim welcome message
  ws.send(JSON.stringify({
    type: 'welcome',
    device_name: DEVICE_NAME,
    device_token: DEVICE_TOKEN,
    version: '1.0.0'
  }));

  ws.on('message', async (messageData) => {
    try {
      const message = JSON.parse(messageData.toString());
      console.log(`[WebSocket] Received message type: ${message.type}`);

      switch (message.type) {
        case 'ping':
          ws.send(JSON.stringify({
            type: 'pong',
            timestamp: Date.now()
          }));
          break;

        case 'execute_automation':
          handleExecuteAutomation(ws, message);
          break;

        case 'register_device':
          await handleRegisterDevice(ws, message);
          break;

        case 'get_status':
          ws.send(JSON.stringify({
            type: 'status',
            device_name: DEVICE_NAME,
            isExecuting: executor.getExecutionStatus(),
            totalExecutions: executor.getTotalExecutions()
          }));
          break;

        default:
          console.warn(`[WebSocket] Unknown message type: ${message.type}`);
          ws.send(JSON.stringify({
            type: 'error',
            error: `Unknown message type: ${message.type}`
          }));
      }
    } catch (error) {
      console.error(`[WebSocket] Error processing message:`, error);
      ws.send(JSON.stringify({
        type: 'error',
        error: error.message
      }));
    }
  });

  ws.on('error', (error) => {
    console.error(`[WebSocket] Error:`, error);
  });

  ws.on('close', () => {
    console.log(`[WebSocket] Connection closed`);
  });
});

// Handle WebSocket automation execution
async function handleExecuteAutomation(ws, message) {
  const executionId = message.executionId || uuidv4();

  ws.send(JSON.stringify({
    type: 'execution_started',
    executionId,
    message: 'Starting automation execution...'
  }));

  try {
    const result = await executor.executeAutomation(message.data, executionId, (progress) => {
      // Send progress updates
      ws.send(JSON.stringify({
        type: 'execution_progress',
        executionId,
        progress
      }));
    });

    ws.send(JSON.stringify({
      type: 'execution_completed',
      executionId,
      result
    }));

    // Juga report ke backend
    await manager.reportExecutionResult(executionId, result);
  } catch (error) {
    console.error(`[Execution Error]`, error);
    ws.send(JSON.stringify({
      type: 'execution_error',
      executionId,
      error: error.message
    }));

    await manager.reportExecutionError(executionId, error);
  }
}

// Handle device registration
async function handleRegisterDevice(ws, message) {
  try {
    const registered = await manager.registerDevice(message.backendUrl);
    ws.send(JSON.stringify({
      type: 'device_registered',
      success: registered,
      device_id: manager.getDeviceId()
    }));
  } catch (error) {
    ws.send(JSON.stringify({
      type: 'registration_error',
      error: error.message
    }));
  }
}

// Auto register device ke backend
async function registerDeviceAtStartup() {
  try {
    await manager.registerDevice();
    // console.log(`[Device] Successfully registered to backend`);
    // console.log(`[Device] Device ID: ${manager.getDeviceId()}`);
    // console.log(`[Device] Device Name: ${DEVICE_NAME}`);
    // console.log(`[Device] Ready to poll for executions...`);
  } catch (error) {
    //console.warn(`[Device] Failed to register to backend:`, error.message);
    //console.log(`[Device] Retrying in 10 seconds...`);
    setTimeout(registerDeviceAtStartup, 10000);
  }
}

// Heartbeat registration - re-register device setiap 30 detik untuk maintain connection
async function heartbeatRegistration() {
  try {
    const deviceId = manager.getDeviceId();
    console.debug(`[Heartbeat] Sending heartbeat to maintain device connection...`);
    
    await manager.registerDevice();
    console.debug(`[Heartbeat] Device connection refreshed (Device ID: ${deviceId})`);
  } catch (error) {
    console.warn(`[Heartbeat] Failed to send heartbeat:`, error.message);
    // Will retry on next heartbeat cycle
  }
}

// Poll backend untuk execution queue
async function pollExecutionQueue() {
  try {
    const deviceId = manager.getDeviceId();
    console.log(`[Poll] Polling for execution queue... (Device ID: ${deviceId})`);
    
    const response = await axios.get(
      `${BACKEND_URL}/api/device-executor/queue/${deviceId}`,
      {
        headers: {
          Authorization: `Bearer ${DEVICE_TOKEN}`
        },
        timeout: 5000
      }
    );

    if (response.data.success && response.data.executions && response.data.executions.length > 0) {
      console.log(`[Poll] Found ${response.data.executions.length} pending execution(s)`);
      
      // Process each execution
      for (const execution of response.data.executions) {
        handleExecutionFromBackend(execution);
      }
    } else {
      console.debug(`[Poll] No pending executions (count: ${response.data.count || 0})`);
    }
  } catch (error) {
    // Log error details
    if (error.response?.status === 401) {
      console.error(`[Poll] Unauthorized (401) - Device ID or Token mismatch`);
      console.error(`[Poll] Device ID: ${manager.getDeviceId()}`);
      console.error(`[Poll] Check that device is registered and token is correct`);
    } else {
      console.debug(`[Poll] Error polling queue: ${error.message}`);
    }
  }
}

// Handle execution dari backend queue
async function handleExecutionFromBackend(execution) {
  const { executionId, testrun_id, testcase_id, environment_id, steps, options = {} } = execution;

  console.log(`[Execution] Processing queued execution ${executionId}`);

  executor.queueExecution({
    steps,
    stopOnFailure: options.stopOnFailure !== false
  }, executionId)
    .then(result => {
      console.log(`[Execution] Completed ${executionId}, reporting result...`);
      manager.reportExecutionResult(executionId, result);
    })
    .catch(error => {
      console.error(`[Execution] Failed ${executionId}:`, error.message);
      manager.reportExecutionError(executionId, error);
    });
}


// --- Polling with Exponential Backoff ---
let pollIntervalMs = 20000; // default 20 detik
const POLL_INTERVAL_DEFAULT = 20000;
const POLL_INTERVAL_MAX = 300000; // 5 menit
let pollTimeout = null;

async function pollExecutionQueueWithBackoff() {
  try {
    await pollExecutionQueue();
    // Jika sukses, reset interval ke default
    if (pollIntervalMs !== POLL_INTERVAL_DEFAULT) {
      console.log(`[Backoff] Polling success, reset interval ke ${POLL_INTERVAL_DEFAULT / 1000}s`);
    }
    pollIntervalMs = POLL_INTERVAL_DEFAULT;
  } catch (error) {
    if (error?.response?.status === 429) {
      // Exponential backoff
      pollIntervalMs = Math.min(pollIntervalMs * 2, POLL_INTERVAL_MAX);
      console.warn(`[Backoff] Polling error 429, tingkatkan interval ke ${pollIntervalMs / 1000}s`);
    } else {
      // Error lain, interval tetap
      console.warn(`[Backoff] Polling error: ${error.message}`);
    }
  } finally {
    pollTimeout = setTimeout(pollExecutionQueueWithBackoff, pollIntervalMs);
  }
}

// Start server
server.listen(PORT, () => {
  console.log(`[Server] Device Executor listening on port ${PORT}`);
  registerDeviceAtStartup();

  // Mulai polling dengan backoff
  pollExecutionQueueWithBackoff();

  // Heartbeat registration every 30 seconds to maintain connection
  // Especially important for Vercel where backend can be cold-started
  setInterval(heartbeatRegistration, 30000);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('[Server] SIGTERM signal received: closing HTTP server');
  server.close(async () => {
    console.log('[Server] HTTP server closed');
    await executor.cleanup();
    process.exit(0);
  });
});
