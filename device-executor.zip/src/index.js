/**
 * Device Executor - Main Entry Point
 * Menjalankan test automation di device lokal dengan Chrome/Chromium
 * Mendengarkan perintah dari backend via WebSocket atau REST API
 */

import 'dotenv/config';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';
import { DeviceExecutorManager } from './manager.js';
import { PlaywrightExecutor } from './executor.js';

const PORT = process.env.PORT || 3000;
const DEVICE_NAME = process.env.DEVICE_NAME || `device-${uuidv4().slice(0, 8)}`;
const DEVICE_TOKEN = process.env.DEVICE_TOKEN || uuidv4();
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:5000';

console.log(`[Device Executor] Starting device: ${DEVICE_NAME}`);
console.log(`[Device Executor] Device Token: ${DEVICE_TOKEN}`);
console.log(`[Device Executor] Backend URL: ${BACKEND_URL}`);

// Initialize manager dan executor
const manager = new DeviceExecutorManager({
  deviceName: DEVICE_NAME,
  deviceToken: DEVICE_TOKEN,
  backendUrl: BACKEND_URL
});

const executor = new PlaywrightExecutor();

// Create HTTP server untuk REST API fallback
const server = createServer((req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  if (req.url === '/health' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'ok',
      device_name: DEVICE_NAME,
      device_token: DEVICE_TOKEN,
      uptime: process.uptime()
    }));
    return;
  }

  if (req.url === '/status' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      device_name: DEVICE_NAME,
      status: manager.isConnected() ? 'connected' : 'disconnected',
      isExecuting: executor.getExecutionStatus(),
      totalExecutions: executor.getTotalExecutions()
    }));
    return;
  }

  // REST API untuk execute automation (fallback jika WebSocket gagal)
  if (req.url.startsWith('/execute') && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      try {
        const data = JSON.parse(body);
        console.log(`[HTTP] Received execution request for test case: ${data.testcase_id}`);
        console.log(`[HTTP] Steps count: ${data.steps?.length || 0}`);
        
        // Use executionId from backend if provided, otherwise generate new one
        const executionId = data.executionId || uuidv4();
        
        // Queue execution untuk handle batch sequentially
        executor.queueExecution(data, executionId)
          .then(result => {
            console.log(`[HTTP] Execution ${executionId} completed successfully`);
            console.log(`[HTTP] Reporting result with device_id: ${manager.getDeviceId()}`);
            manager.reportExecutionResult(executionId, result);
          })
          .catch(error => {
            console.error(`[HTTP] Execution ${executionId} failed:`, error.message);
            console.log(`[HTTP] Reporting error with device_id: ${manager.getDeviceId()}`);
            manager.reportExecutionError(executionId, error);
          });

        res.writeHead(202, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: true,
          executionId,
          message: 'Execution queued'
        }));
      } catch (error) {
        console.error(`[HTTP] Parse error:`, error);
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: error.message
        }));
      }
    });
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

// WebSocket Server untuk realtime communication
const wss = new WebSocketServer({ server });

wss.on('connection', (ws, req) => {
  console.log(`[WebSocket] New connection from ${req.socket.remoteAddress}`);

  // Kirim welcome message
  ws.send(JSON.stringify({
    type: 'welcome',
    device_name: DEVICE_NAME,
    device_token: DEVICE_TOKEN,
    version: '1.0.0'
  }));

  ws.on('message', async (messageData) => {
    try {
      const message = JSON.parse(messageData.toString());
      console.log(`[WebSocket] Received message type: ${message.type}`);

      switch (message.type) {
        case 'ping':
          ws.send(JSON.stringify({
            type: 'pong',
            timestamp: Date.now()
          }));
          break;

        case 'execute_automation':
          handleExecuteAutomation(ws, message);
          break;

        case 'register_device':
          await handleRegisterDevice(ws, message);
          break;

        case 'get_status':
          ws.send(JSON.stringify({
            type: 'status',
            device_name: DEVICE_NAME,
            isExecuting: executor.getExecutionStatus(),
            totalExecutions: executor.getTotalExecutions()
          }));
          break;

        default:
          console.warn(`[WebSocket] Unknown message type: ${message.type}`);
          ws.send(JSON.stringify({
            type: 'error',
            error: `Unknown message type: ${message.type}`
          }));
      }
    } catch (error) {
      console.error(`[WebSocket] Error processing message:`, error);
      ws.send(JSON.stringify({
        type: 'error',
        error: error.message
      }));
    }
  });

  ws.on('error', (error) => {
    console.error(`[WebSocket] Error:`, error);
  });

  ws.on('close', () => {
    console.log(`[WebSocket] Connection closed`);
  });
});

// Handle WebSocket automation execution
async function handleExecuteAutomation(ws, message) {
  const executionId = message.executionId || uuidv4();

  ws.send(JSON.stringify({
    type: 'execution_started',
    executionId,
    message: 'Starting automation execution...'
  }));

  try {
    const result = await executor.executeAutomation(message.data, executionId, (progress) => {
      // Send progress updates
      ws.send(JSON.stringify({
        type: 'execution_progress',
        executionId,
        progress
      }));
    });

    ws.send(JSON.stringify({
      type: 'execution_completed',
      executionId,
      result
    }));

    // Juga report ke backend
    await manager.reportExecutionResult(executionId, result);
  } catch (error) {
    console.error(`[Execution Error]`, error);
    ws.send(JSON.stringify({
      type: 'execution_error',
      executionId,
      error: error.message
    }));

    await manager.reportExecutionError(executionId, error);
  }
}

// Handle device registration
async function handleRegisterDevice(ws, message) {
  try {
    const registered = await manager.registerDevice(message.backendUrl);
    ws.send(JSON.stringify({
      type: 'device_registered',
      success: registered,
      device_id: manager.getDeviceId()
    }));
  } catch (error) {
    ws.send(JSON.stringify({
      type: 'registration_error',
      error: error.message
    }));
  }
}

// Auto register device ke backend
async function registerDeviceAtStartup() {
  try {
    await manager.registerDevice();
    console.log(`[Device] Successfully registered to backend`);
  } catch (error) {
    console.warn(`[Device] Failed to register to backend:`, error.message);
    console.log(`[Device] Retrying in 5 seconds...`);
    setTimeout(registerDeviceAtStartup, 5000);
  }
}

// Start server
server.listen(PORT, () => {
  console.log(`[Server] Device Executor listening on port ${PORT}`);
  registerDeviceAtStartup();
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('[Server] SIGTERM signal received: closing HTTP server');
  server.close(async () => {
    console.log('[Server] HTTP server closed');
    await executor.cleanup();
    process.exit(0);
  });
});
